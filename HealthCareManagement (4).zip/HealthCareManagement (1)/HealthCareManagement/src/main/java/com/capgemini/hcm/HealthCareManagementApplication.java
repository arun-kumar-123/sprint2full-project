 package com.capgemini.hcm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthCareManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthCareManagementApplication.class, args);
	}

}

//package com.capgemini.hcm.dao;
//
//public class DiagnosticCenterDao1 {
//
//	public boolean deletecenter(Integer centerId) {
//		
//	}
//}

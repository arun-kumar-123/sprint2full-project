package com.capgemini.hcm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthCareManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}

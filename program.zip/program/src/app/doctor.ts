export class Doctor {
    doctorId:number;
    doctorName:String;
    contactNumber:number;
    doctorSpecialization:String;
    
}

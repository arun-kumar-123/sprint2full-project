import { DiagnosticCenter } from './diagnostic-center';

describe('DiagnosticCenter', () => {
  it('should create an instance', () => {
    expect(new DiagnosticCenter()).toBeTruthy();
  });
});

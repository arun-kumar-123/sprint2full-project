import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-removecenter',
  templateUrl: './removecenter.component.html',
  styleUrls: ['./removecenter.component.css']
})
export class RemovecenterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Tests } from './tests';

describe('Tests', () => {
  it('should create an instance', () => {
    expect(new Tests()).toBeTruthy();
  });
});

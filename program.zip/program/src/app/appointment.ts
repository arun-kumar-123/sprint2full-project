export class Appointment {
    appointmentId:number;
    appointmentDateAndTime:String;
    approved:boolean;
}


export class Tests {
    testId:number;
    testName:String;
}

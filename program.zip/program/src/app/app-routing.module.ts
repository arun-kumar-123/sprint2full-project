import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewallcenterComponent } from './viewallcenter/viewallcenter.component';
import { AddcenterComponent } from './addcenter/addcenter.component';
import { RemovecenterComponent } from './removecenter/removecenter.component';
import { UpdatecenterComponent } from './updatecenter/updatecenter.component';




const routes: Routes = [
  {path: '', redirectTo: 'view-DiagnosticCenter', pathMatch: 'full'},
  {path:'view-DiagnosticCenter',component:ViewallcenterComponent},
  {path:'Add-DiagnosticCenter',component:AddcenterComponent},
  {path: 'updateCenter', component: UpdatecenterComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

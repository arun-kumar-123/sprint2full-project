export class DiagnosticCenter {
    centerId:number;
    centerName:String;
}

import { Component, OnInit } from '@angular/core';
import { DiagnosticCenter } from '../diagnostic-center';
import { DiagnosticCenterService } from '../diagnostic-center.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewallcenter',
  templateUrl: './viewallcenter.component.html',
  styleUrls: ['./viewallcenter.component.css']
})
export class ViewallcenterComponent implements OnInit {
 
  diagnosticCenters: DiagnosticCenter[]=[];
   msg:string;
   diagnosticCenter:DiagnosticCenter=new DiagnosticCenter();
   deleteMessage=false;
   viewallcenter:any; 
   isupdates=false;
  

 
  constructor(private diagnosticCenterService:DiagnosticCenterService, private router: Router){console.log("Am in center list");}

  ngOnInit(){
    console.log("Am in center list");
    this.diagnosticCenterService.listallcenter().subscribe(data=>this.diagnosticCenters=data);
    console.log(this.diagnosticCenters);
  } 
  deletecenter(centerId: number) {  
    this.diagnosticCenterService.deletecenter(centerId)  
      .subscribe(  
        data => {  
          console.log(data);  
          this.deleteMessage=true;  
          this.diagnosticCenterService.listallcenter().subscribe(data =>{  
            this.diagnosticCenters =data  
            })  
        },  
        error => console.log(error));  
  }  

}
  


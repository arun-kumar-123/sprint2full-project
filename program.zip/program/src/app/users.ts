export class Users {
    userId:number;
    userPassword:String;
    userName:String;
    contactNo:number;
    userRole:String;
    emailId:String;

}

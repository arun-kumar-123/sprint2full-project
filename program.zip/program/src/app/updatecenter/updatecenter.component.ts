import { Component, OnInit } from '@angular/core';
import { DiagnosticCenter } from '../diagnostic-center';
import { DiagnosticCenterService } from '../diagnostic-center.service';

@Component({
  selector: 'app-updatecenter',
  templateUrl: './updatecenter.component.html',
  styleUrls: ['./updatecenter.component.css']
})
export class UpdatecenterComponent implements OnInit {

  diagnosticCenter: DiagnosticCenter=new DiagnosticCenter();
  msg:String;
  errorMsg:String;
  constructor(private diagnosticCenterService: DiagnosticCenterService) { }
 

  ngOnInit(): void {
  }

  updatecenter(){
    this.diagnosticCenterService.updatecenter(this.diagnosticCenter).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.diagnosticCenter=new DiagnosticCenter()},
      error=>{this.errorMsg=JSON.parse(error.error).message;
      console.log(error.error);
      this.msg=undefined});
  }

}

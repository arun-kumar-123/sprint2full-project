import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DiagnosticCenter } from './diagnostic-center';

@Injectable({
  providedIn: 'root'
})
export class DiagnosticCenterService {
    
  private diagnosticCenters: DiagnosticCenter[]=[];
  constructor(private http:HttpClient) { }

  listallcenter(): Observable<any> {
    console.log("Am inside service");
    return this.http.get("http://localhost:9090/viewallcenter");  
  }

  addcenter(diagnosticCenter:DiagnosticCenter): Observable<any>{
    return this.http.post("http://localhost:9090/addcenter", diagnosticCenter, { responseType: 'text' } ); 
  }

 deletecenter(centerId: number): Observable<any>{
  console.log("inside delete service "+centerId );
  return this.http.delete(`http://localhost:9090/deletecenter/${centerId}`,{responseType:'text'})  ;
 }

  updatecenter(diagnosticCenter:DiagnosticCenter): Observable<any>{
    return this.http.put(`http://localhost:9090/updatecenter/${diagnosticCenter.centerId}`,diagnosticCenter,{responseType:'text'});
  }
  
  listcenterbyId(centerId :number): Observable<object>{
    return this.http.get(`http://localhost:9090/updatecenter/${centerId}`);
  }
  
}

import { Component, OnInit } from '@angular/core';
import{DiagnosticCenterService} from '../diagnostic-center.service'
import { DiagnosticCenter } from '../diagnostic-center';
@Component({
  selector: 'app-addcenter',
  templateUrl: './addcenter.component.html',
  styleUrls: ['./addcenter.component.css']
})
export class AddcenterComponent implements OnInit {

  constructor(private diagnosticCenterService:DiagnosticCenterService) { }

  diagnosticCenter:DiagnosticCenter=new DiagnosticCenter();
  msg:String;
  errorMsg:String;

  ngOnInit(): void {

  }

  addcenter()
  {
    this.diagnosticCenterService.addcenter(this.diagnosticCenter).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.diagnosticCenter=new DiagnosticCenter()},
      error=>{this.errorMsg=JSON.parse(error.error).message;
      console.log(error.error);
      this.msg=undefined});
  }

}

 


